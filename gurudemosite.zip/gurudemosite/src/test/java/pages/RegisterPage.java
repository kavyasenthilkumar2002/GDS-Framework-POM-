package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RegisterPage {

    WebDriver driver;

    public RegisterPage(WebDriver driver) {
        this.driver = driver;
    }

    // Locators
    By firstName = By.name("firstName");
    By lastName = By.name("lastName");
    By phone = By.name("phone");
    By email = By.id("userName");

    By address = By.name("address1");
    By city = By.name("city");
    By state = By.name("state");
    By postalCode = By.name("postalCode");
    By country = By.name("country");

    By username = By.id("email");
    By password = By.name("password");
    By confirmPassword = By.name("confirmPassword");

    By submitBtn = By.name("submit");

    // Actions
    public void enterFirstName(String fname) {
        driver.findElement(firstName).sendKeys(fname);
    }

    public void enterLastName(String lname) {
        driver.findElement(lastName).sendKeys(lname);
    }

    public void enterPhone(String ph) {
        driver.findElement(phone).sendKeys(ph);
    }

    public void enterEmail(String mail) {
        driver.findElement(email).sendKeys(mail);
    }

    public void enterAddress(String addr) {
        driver.findElement(address).sendKeys(addr);
    }

    public void enterCity(String c) {
        driver.findElement(city).sendKeys(c);
    }

    public void enterState(String s) {
        driver.findElement(state).sendKeys(s);
    }

    public void enterPostalCode(String pc) {
        driver.findElement(postalCode).sendKeys(pc);
    }

    public void enterCountry(String cnt) {
        driver.findElement(country).sendKeys(cnt);
    }

    public void enterUsername(String user) {
        driver.findElement(username).sendKeys(user);
    }

    public void enterPassword(String pass) {
        driver.findElement(password).sendKeys(pass);
    }

    public void enterConfirmPassword(String cpass) {
        driver.findElement(confirmPassword).sendKeys(cpass);
    }

    public void clickSubmit() {
        driver.findElement(submitBtn).click();
    }
}