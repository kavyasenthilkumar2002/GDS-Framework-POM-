package tests;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.RegisterPage;

public class RegisterTest extends BaseTest {

    RegisterPage register;

    @BeforeTest
    public void start() {
        setup();
        register = new RegisterPage(driver); // ✅ FIXED
    }

    @Test
    public void registerUser() {

        register.enterFirstName("Kavya");
        register.enterLastName("S");
        register.enterPhone("9876543210");
        register.enterEmail("kavya@test.com");

        register.enterAddress("Chennai");
        register.enterCity("Chennai");
        register.enterState("Tamil Nadu");
        register.enterPostalCode("600001");
        register.enterCountry("INDIA");

        register.enterUsername("kavya123");
        register.enterPassword("12345");
        register.enterConfirmPassword("12345");

        register.clickSubmit();
    }

    @AfterTest
    public void end() {
        tearDown();
    }
}